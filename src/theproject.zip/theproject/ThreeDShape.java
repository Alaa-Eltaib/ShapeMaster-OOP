package theproject;

public abstract class ThreeDShape extends Shape {

	public ThreeDShape() {
		super();
	}
	
 public ThreeDShape(String colorcube) {
		super(colorcube);
	}



public abstract double getVolume();
	

}
