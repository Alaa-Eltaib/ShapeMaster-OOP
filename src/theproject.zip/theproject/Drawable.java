package theproject;

public interface Drawable {
	
	String howToDraw();
	
	

}
